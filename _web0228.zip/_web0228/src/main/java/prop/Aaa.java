package prop;

public class Aaa {
	void aaaprint() {
		System.out.println("Aaa 객체의 메소드");
	}
}
