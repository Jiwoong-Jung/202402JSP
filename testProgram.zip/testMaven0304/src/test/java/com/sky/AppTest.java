package com.sky;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.util.Properties;
import org.junit.Test;


public class AppTest {

    private App app = new App();


    @Test
    public void loadProperties_테스트합니다() {

        Properties properties = app.loadProperties("/book.properties");


        assertThat("book.name 테스트", properties.getProperty("book.name"), is("Spring5 Programming"));
        assertThat("book.publisher 테스트", properties.getProperty("book.publisher"), is("choi"));
    }

}
