package prop;

public class Aaa {
	void print() {
		System.out.println("Aaa 클래스");
	}
}
