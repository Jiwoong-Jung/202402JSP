package ramda;

public interface MyFuncInter {
	public void method(int x, int y);
}
