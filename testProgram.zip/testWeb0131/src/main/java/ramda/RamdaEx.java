package ramda;

public class RamdaEx {

	public static void main(String[] args) {
		MyFuncInter myi, myi2;
		
		myi = new MyFuncInter() {
			
			@Override
			public void method(int x, int y) {
				System.out.println(x+y);
				
			}
		};
		
		myi.method(100, 200);
		
		myi2 = (a, b) -> {
			System.out.println(a+b);
		};
		myi2.method(30, 40);

	}

}
